#ifndef CUSTEMP_H
#define CUSTEMP_H

namespace tmax {
	template <typename T> T myMax(T a, T b);
};

#endif
