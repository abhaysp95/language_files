#include "template.hpp"

namespace tmax {
	template <typename T>
	T myMax(T a, T b) {
		return a > b ? a : b;
	}
};
