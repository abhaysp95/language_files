#include <stdio.h>
#include "a.h"
#include "b.h"
#include "c.h"
#include "d.h"

int main(int argc, char **argv) {
	a();
	b();
	c();
	d();
	return 0;
}
