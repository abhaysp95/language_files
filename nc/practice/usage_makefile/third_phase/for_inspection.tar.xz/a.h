#include <stdio.h>

void a();
