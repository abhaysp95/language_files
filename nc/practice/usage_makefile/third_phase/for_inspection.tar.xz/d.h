#include <stdio.h>

void d();
