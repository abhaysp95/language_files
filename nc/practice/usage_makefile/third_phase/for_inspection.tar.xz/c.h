#include <stdio.h>

void c();
