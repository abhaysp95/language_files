#include "a.h"

void a() {
	printf("I'm a\n");

}
