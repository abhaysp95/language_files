#include "b.h"

void b() {
	printf("I'm b\n");

}
