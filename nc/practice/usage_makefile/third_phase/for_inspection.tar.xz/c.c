#include "c.h"

void c() {
	printf("I'm c\n");

}
