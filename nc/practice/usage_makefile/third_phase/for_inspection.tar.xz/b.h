#include <stdio.h>

void b();
