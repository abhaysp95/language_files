#include "d.h"

void d() {
	printf("I'm d\n");

}
