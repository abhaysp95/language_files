package testing_interface;

public interface ITest {
	void show(int n);
}
